create definer = root@localhost trigger Insert_note_when_insert_etu
    after insert
    on etudiant
    for each row
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE c1 VARCHAR(12);
    DECLARE cur CURSOR FOR select e.idEnseignement from enseignement e INNER JOIN module m ON e.idModule= m.idModule where m.idForma= new.idForma;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;
        ins_loop: LOOP
            FETCH cur INTO c1;
            IF done THEN
                LEAVE ins_loop;
            END IF;
            insert into note(numEtu, idEnseignement, noteTP,noteCC1, noteCC2, noteExam,session, AnnéeUniv) value(new.numEtu, c1 , null, null, null, null, 1, (select concat(convert(annee,char), "-", convert(annee + 1, char)) from annee));
        END LOOP;
    CLOSE cur;
END;

